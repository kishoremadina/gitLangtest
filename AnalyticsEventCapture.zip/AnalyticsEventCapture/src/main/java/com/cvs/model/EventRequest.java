package com.cvs.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.databind.JsonNode;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EventRequest {
	@JsonProperty
	private String eventSource;
	private String eventCategory;
	private String eventStatus;

	@JsonRawValue
	private String payLoad;
	private String dateCreated;

	public String getEventSource() {
		return eventSource;
	}

	public void setEventSource(String eventSource) {
		this.eventSource = eventSource;
	}

	public String getEventCategory() {
		return eventCategory;
	}

	public void setEventCategory(String eventCategory) {
		this.eventCategory = eventCategory;
	}

	public String getEventStatus() {
		return eventStatus;
	}

	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}

	@JsonRawValue
	public String getPayLoad() {
		return payLoad;
	}

	public void setPayLoad(JsonNode payLoad) {
		this.payLoad = payLoad.toString();
	}

	/*
	 * @JsonProperty(value = "payload") public void setJsonRaw(JsonNode jsonNode) {
	 * setPayLoad(jsonNode.toString()); }
	 */
	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

}
