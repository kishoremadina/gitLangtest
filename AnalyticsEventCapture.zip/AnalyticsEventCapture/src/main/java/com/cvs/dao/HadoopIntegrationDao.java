package com.cvs.dao;

import org.springframework.stereotype.Repository;

import com.cvs.model.EventRequest;
import com.cvs.model.EventResponse;

@Repository
public interface HadoopIntegrationDao {

	public EventResponse saveAnalyticsEvent(EventRequest request) throws Exception;
}
