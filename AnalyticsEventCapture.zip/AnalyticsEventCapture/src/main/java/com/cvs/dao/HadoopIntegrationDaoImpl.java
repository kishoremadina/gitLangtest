package com.cvs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.cvs.constants.QueryConstants;
import com.cvs.model.EventRequest;
import com.cvs.model.EventResponse;

@Repository
public class HadoopIntegrationDaoImpl implements HadoopIntegrationDao {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	public JdbcTemplate jdbcTemplate;
	
	@Override
	public EventResponse saveAnalyticsEvent(EventRequest request) throws Exception {
		logger.info("ENTER: saveAnalyticsEvent");
		EventResponse response = new EventResponse();
		KeyHolder holder = new GeneratedKeyHolder(); 
	
		jdbcTemplate.update(new PreparedStatementCreator() {

				@Override
				public PreparedStatement createPreparedStatement(Connection con) {
					PreparedStatement ps = null;
					try{
						ps = con.prepareStatement(QueryConstants.INSERT_EVENT_DETAILS);
						ps.setString(1, request.getEventSource());
						ps.setString(2, request.getEventCategory());
						ps.setString(3, request.getEventStatus());
						ps.setString(4, request.getPayLoad().toString());
						ps.setObject(5, request.getDateCreated());
						
					}catch (Exception e) {
						logger.error("Error While Posting the data to DB"+ExceptionUtils.getStackTrace(e));
					}
					return ps;
				}
			},holder);
		
		logger.info("HadoopIntegrationDaoImpl....RecordId ::> "+holder.getKey().toString());
		System.out.println("HadoopIntegrationDaoImpl....RecordId ::> "+holder.getKey().toString());
		response.setStatus(QueryConstants.EVENT_STATUS_RECIEVED);
		logger.info("EXIT: saveAnalyticsEvent");
		return response;
	
	}
}
