package com.cvs.config;

import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;

public class AsyncExceptionHandler implements AsyncUncaughtExceptionHandler {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public void handleUncaughtException(Throwable throwable, Method method, Object... obj) {
		logger.error("Exception Cause - " + throwable.getMessage());
		logger.error("Method name - " + method.getName());
		for (Object param : obj) {
			logger.error("Parameter value - " + param);
		}
	}
}