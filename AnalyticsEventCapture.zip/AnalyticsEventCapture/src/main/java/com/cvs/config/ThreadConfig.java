package com.cvs.config;

import java.util.concurrent.Executor;

import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync
public class ThreadConfig implements AsyncConfigurer {
    
	@Bean(name = "threadPoolExecutor")
    public TaskExecutor threadPoolTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5); // TODO  All these would go to application.properties and these based on the forlulae N_threads = N_cpu * U_cpu * (1 + W / C)
        executor.setMaxPoolSize(100); //TODO  N_threads = N_cpu * U_cpu * (1 + W / C)
        executor.setQueueCapacity(50);
        executor.setThreadNamePrefix("AnalyticsEventCapture->");
        executor.initialize();
        return executor;
    }
	
	 @Override
	    public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
	        return new AsyncExceptionHandler();
	    }

	@Override
	public Executor getAsyncExecutor() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
