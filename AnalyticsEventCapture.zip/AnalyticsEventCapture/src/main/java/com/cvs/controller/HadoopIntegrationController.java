package com.cvs.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cvs.constants.QueryConstants;
import com.cvs.model.EventRequest;
import com.cvs.model.EventResponse;
import com.cvs.service.HadoopIntegrationService;
import com.cvs.utility.Utility;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping(value = "/")
public class HadoopIntegrationController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	public HadoopIntegrationService service;

	@RequestMapping(value = "/sendanalyticsevent", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public Map<String, Object> sendAnalyticsEvent(@RequestBody String eventRequestStr)
			throws InterruptedException, ExecutionException {
		logger.info("ENTER: sendAnalyticsEvent");
		Map<String, Object> responseMap = new HashMap<String, Object>();
		ObjectMapper mapper = new ObjectMapper();
		EventRequest eventRequest;
		try {
			eventRequest = mapper.readValue(eventRequestStr, EventRequest.class);
		} catch (IOException e) {
			generateErrorResponse(responseMap,QueryConstants.RESPONSE_PARSE_ERROR,HttpStatus.BAD_REQUEST.toString());
			return responseMap;
		}

		
		if (validateRequestData(eventRequest)) {
			eventRequest.setDateCreated(Utility.getCurrentDate());
			eventRequest.setEventStatus(QueryConstants.EVENT_STATUS_RECIEVED);
			try {
				CompletableFuture<EventResponse> resopnse = service.saveAnalyticsEvent(eventRequest);
				if(resopnse.isDone())
				logEventResponse(resopnse.get());
				responseMap.put("status", resopnse.get().getStatus());
				responseMap.put("error", null);
				responseMap.put("message", QueryConstants.RESPONSE_SUCCESS);
				responseMap.put("timestamp", System.currentTimeMillis());
				return responseMap;
			} catch (Exception e) {
				generateErrorResponse(responseMap,QueryConstants.RESPONSE_ERROR,HttpStatus.INTERNAL_SERVER_ERROR.toString());
				return responseMap;
			}
		}
		generateErrorResponse(responseMap,QueryConstants.RESPONSE_ERROR,HttpStatus.BAD_REQUEST.toString());
		logger.info("Exit: sendAnalyticsEvent");
		return responseMap;
	}

	private void generateErrorResponse(Map<String, Object> responseMap, String message, String status) {
		responseMap.put("status", QueryConstants.EVENT_STATUS_ERROR);
		responseMap.put("error", status);
		responseMap.put("message", message);
		responseMap.put("timestamp", System.currentTimeMillis());
		EventResponse resp = new EventResponse();
		resp.setRecordId(null);
		resp.setMessage(QueryConstants.RESPONSE_ERROR);
		resp.setStatus(QueryConstants.EVENT_STATUS_ERROR);
		logEventResponse(resp);
	}

	private void logEventResponse(EventResponse response) {
		if (response.getRecordId() == null) {
			logger.error("Error while saving the Analytics Event. The response status :: [" + response.getStatus()
					+ "] Error Message:: [" + response.getMessage() + "]");
		}

	}

	private boolean validateRequestData(EventRequest eventRequest) {
		
		if ((hasValidContent(eventRequest.getEventCategory()) && hasValidContent(eventRequest.getEventSource())
				&& hasValidContent(eventRequest.getPayLoad()  ))){
			return true;
		}
		return false;
	}
	
	private boolean hasValidContent(String val) {
		if(null == val || val.trim().equals(""))
			return false;
		return true;
	}

	public String welcome() {
		return "Welcome to AnalyticsEventCapture MicroService";
	}
}
