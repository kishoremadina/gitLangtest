package com.cvs.constants;

public interface QueryConstants {

	String INSERT_EVENT_DETAILS = "INSERT INTO MESSAGE_STAGING_TABLE (RECORD_SOURCE, RECORD_CATEGORY, RECORD_STATUS, MESSAGE_CONTENTS, DATE_CREATED) VALUES (?, ?, ?, ?, ?);";
	
	String EVENT_STATUS_RECIEVED = "RECEIVED";
	String EVENT_STATUS_PROCESSING = "PROCESSING";
	String EVENT_STATUS_PROCESSED = "PROCESSED";
	String EVENT_STATUS_ERROR = "ERROR";
	
	String RESPONSE_STATUS_SUCCESS = "SUCCESS";
	String RESPONSE_STATUS_FAILURE = "FAILURE";
//	String RESPONSE_MSG_1 = "Error connecting Maria DB. Please try sometime later.";
	
	String RESPONSE_ERROR = "Missing mandatory fields in request";
	String RESPONSE_PARSE_ERROR = "Malformed JSON supplied in request";
	String RESPONSE_SUCCESS = "Sucessfully posted the data";

}
