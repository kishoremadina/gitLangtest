package com.cvs.service;

import java.util.concurrent.CompletableFuture;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.cvs.dao.HadoopIntegrationDao;
import com.cvs.model.EventRequest;
import com.cvs.model.EventResponse;

@Service
public class HadoopIntegrationServiceImpl implements HadoopIntegrationService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	public HadoopIntegrationDao dao;
	
	@Override
	
	@Async("threadPoolExecutor")
	public CompletableFuture<EventResponse> saveAnalyticsEvent(EventRequest request) throws Exception {
		logger.info("ENTER: saveAnalyticsEvent");
		logger.info("HadoopIntegrationServiceImpl Current Thread Name ==> " + Thread.currentThread().getName());
		System.out.println("HadoopIntegrationServiceImpl Current Thread Name ==> " + Thread.currentThread().getName());
		try {
			EventResponse resopnse = dao.saveAnalyticsEvent(request);
			logger.info("EXIT: saveAnalyticsEvent");
			return CompletableFuture.completedFuture(resopnse);
		} catch (Exception e) {
			logger.error("Error whhile storing to DB"+ExceptionUtils.getStackTrace(e));
			return null;
		}
		
	}
	
	

}
