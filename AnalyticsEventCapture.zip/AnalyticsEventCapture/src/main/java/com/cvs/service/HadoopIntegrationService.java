package com.cvs.service;

import java.util.concurrent.CompletableFuture;

import org.springframework.stereotype.Service;

import com.cvs.model.EventRequest;
import com.cvs.model.EventResponse;

@Service
public interface HadoopIntegrationService {

	public CompletableFuture<EventResponse> saveAnalyticsEvent(EventRequest request) throws  Exception;
}
