
package com.developers.perspective.scenarios

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object PostData {

  val data = "{\"eventSource\": \"ERE\",\n\n  \"eventCategory\": \"EWS\", \"payLoad\": {\n\n    \"workRequestId\": \"workRequest001\"}}"

  val postUserHttp = http("post data")
    .post("http://localhost:8080/AnalyticsEventCapture/sendanalyticsevent")
    .body(StringBody(data))
    .check(status is 200)

  val postUser = scenario("post data")
    .exec(postUserHttp)
}