

package com.developers.perspective.util



object Environemnt {
  val baseURL = scala.util.Properties.envOrElse("baseURL", "http://localhost:8080/AnalyticsEventCapture/")
  val users = scala.util.Properties.envOrElse("numberOfUsers", "5000")
  val maxResponseTime = scala.util.Properties.envOrElse("maxResponseTime", "1000") // in milliseconds

}
