package com.developers.perspective.simulation

/**
  * Created by dmumma on 11/20/15.
  */

import com.developers.perspective.util._
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import com.developers.perspective.scenarios.PostData

class AnalyticsMicroService extends Simulation {

  val httpConf = http.baseURL(Environemnt.baseURL)
                      .headers(Headers.commonHeader)

  val userMicroserviceScenarios = List(
    PostData.postUser.inject(atOnceUsers(Environemnt.users.toInt))
     //.throttle(reachRps(100) in (20 seconds), holdFor(60 seconds))
  )

  setUp(userMicroserviceScenarios)
    .protocols(httpConf)
    .maxDuration(1 minutes)
    .assertions(
      global.responseTime.max.lessThan(Environemnt.maxResponseTime.toInt)
    )
}