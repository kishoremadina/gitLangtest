package com.developers.perspective.util

object Headers {
  val commonHeader = Map(

    "Content-Type" ->"application/json"

  )
}
